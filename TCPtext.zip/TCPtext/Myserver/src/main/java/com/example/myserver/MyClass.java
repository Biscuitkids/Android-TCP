package com.example.myserver;

import java.io.IOException;
import java.io.OutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.List;


public class MyClass {
    

    public static List<Socket> listSocket = new ArrayList<>();

    public static void main(String[] args) throws IOException {
        ServerSocket serverSocket = new ServerSocket(3000);
        System.out.append("服务器已创建");
        System.out.println("等待接受连接");
        while (true) {
            Socket socket = serverSocket.accept();
            System.out.println("新的设备连接到服务器");//有客户端连接时，显示文字
            new Thread(new ServerThread(socket)).start();
        }
    }
}