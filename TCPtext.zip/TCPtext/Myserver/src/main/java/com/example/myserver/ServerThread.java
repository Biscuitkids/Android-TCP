package com.example.myserver;

import org.omg.CORBA.portable.InputStream;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.Socket;
import java.util.Iterator;

public class ServerThread implements Runnable {

    private Socket socket;
    private BufferedReader br;


    public ServerThread(Socket socket) throws IOException {
        this.socket = socket;
        br = new BufferedReader(new InputStreamReader(socket.getInputStream(), "utf-8"));
    }

    @Override
    public void run() {
        String content;
        while ((content = readFromClient()) != null)
        {
            for (Iterator<Socket> iterator = MyClass.listSocket.iterator(); iterator.hasNext(); ) {
                Socket socket = iterator.next();
                System.out.println("IP:" + socket.getInetAddress() + "    port:" + socket.getPort());
                try {
                    OutputStream os = socket.getOutputStream();
                    os.write((content + "\n").getBytes("utf-8"));
                    os.close();
                    socket.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    private String readFromClient() {
        try {
            return br.readLine();
        } catch (IOException e) {
            e.printStackTrace();
            MyClass.listSocket.remove(socket);
        }
        return null;
    }
}
