package com.example.tcptext;

import android.util.Log;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.InputStream;
import java.net.Socket;

public class Receive extends Thread {
    private InputStream inputStream;
    private InputStreamReader inputStreamReader;
    private BufferedReader bufferedReader;
    private int port;
    private String ip;

    public Receive(int port, String ip) {
        this.port = port;
        this.ip = ip;
    }

    @Override
    public void run() {
        try {
            Socket socket = new Socket(ip,port);
            socket.shutdownOutput();
            inputStream = socket.getInputStream();
            inputStreamReader = new InputStreamReader(inputStream);
            bufferedReader = new BufferedReader(inputStreamReader);
            String msg = null;
            msg = bufferedReader.readLine();
            while((msg=bufferedReader.readLine()) != null) {
                //socket.close();
                Log.v("AndroidChat","服务器说："+msg);
                System.out.println("服务器说："+msg);
            }

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}