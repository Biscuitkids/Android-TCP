package com.example.tcptext;


import android.util.Log;

import java.io.IOException;
import java.io.OutputStream;
import java.io.InputStream;
import java.net.Socket;

public class ConnectThread extends Thread {
    //Socket msg = null;//定义socket
    private OutputStream out_ip=null;//定义输出流（ip）
    OutputStream outputStream=null;
    private InputStream inputStream;
    private StringBuffer stringBuffer;
    private String ip;
    private int port;

    public ConnectThread(String ip, int port) {
        this.ip = ip;
        this.port = port;
    }


    @Override
        public void run(){
            System.out.println(Thread.currentThread().getName() + ": Hello");
            try {
                Socket so = new Socket(ip, port);
                inputStream = so.getInputStream();
                out_ip = so.getOutputStream();
                Log.v("AndroidChat","开始连接服务器："+ip+"/"+port);
            }
               catch (IOException e) {
                Log.v("AndroidChat","连接服务器失败"+e.getMessage());
                e.printStackTrace();
                return;
            }
            Log.v("AndroidChat","成功连接上服务器");
    }

    /*private String readMsg() {
        try {
            StringBuffer stringBuffer = new StringBuffer();
            int t= inputStream.read();
            while (t!='#'){
            Log.v("AndroidChat","接收到一个字节："+t);
            stringBuffer.append((char)t);
            t=inputStream.read();
            }
            String inMsg = stringBuffer.toString();
            Log.v("AndroidChat","接收到一条消息："+inMsg);
            return inMsg;
        } catch (Exception e) {
            Log.v("AndroidChat","接收信息出错："+e.getMessage());
            e.printStackTrace();
        }
        return "error";
    }*/
}

