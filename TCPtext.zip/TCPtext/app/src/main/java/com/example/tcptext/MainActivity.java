package com.example.tcptext;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import java.io.IOException;
import java.io.InputStream;
import java.net.Socket;
import java.net.UnknownHostException;

public class MainActivity extends AppCompatActivity {
     private Button mBtn_send;
     private Button mBtn_connect;
     private EditText mEt_send;
     private TextView mTv_recv;
     private EditText mEt_ip;
     private EditText mEt_port;
     private String ip;
     private int port;
     private String msg;
     private ConnectThread ct;
     private Send send;
     private Receive receive;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mTv_recv = findViewById(R.id.receive);
        mBtn_connect=findViewById(R.id.connect);
        mBtn_send=findViewById(R.id.btn_1);
        final EditText mEt_ip=this.findViewById(R.id.ip);
        final EditText mEt_port=this.findViewById(R.id.port);
        final EditText mEt_send=this.findViewById(R.id.send);



        mBtn_connect.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ip = mEt_ip.getText().toString();//获取输入的ip
                port = Integer.parseInt(mEt_port.getText().toString());//获取输入的端口号
                ct = new ConnectThread(ip,port);//创建一个线程来处理消息的收发
                ct.start();
            }
        });

        mBtn_send.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                    msg = mEt_send.getText().toString();
                    send = new Send(msg,port,ip);
                    send.start();
            }
        });
        receive = new Receive(port,ip);
        receive.start();
        }
    }
